"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const obsidian_1 = require("obsidian");
const types_1 = require("./types");
const ButtonService_1 = require("./services/ButtonService");
const ViewManager_1 = require("./services/ViewManager");
const SettingsService_1 = require("./services/SettingsService");
const NotificationService_1 = require("./services/NotificationService");
const FileAnalysisService_1 = require("./services/FileAnalysisService");
const DataviewAdapter_1 = require("./services/DataviewAdapter");
const AreaLayoutService_1 = require("./services/AreaLayoutService");
const AreaCreationService_1 = require("./services/AreaCreationService");
class PrintTitlePlugin extends obsidian_1.Plugin {
    constructor() {
        super(...arguments);
        this.customStyleEl = null;
    }
    async onload() {
        this.log('Loading Print Title Plugin v2.0.0...');
        // Load settings
        await this.loadSettings();
        // Initialize services
        this.notificationService = new NotificationService_1.NotificationService(this.settings);
        this.fileAnalysisService = new FileAnalysisService_1.FileAnalysisService(this.app, this.settings);
        this.dataviewAdapter = new DataviewAdapter_1.DataviewAdapter(this.app);
        this.areaLayoutService = new AreaLayoutService_1.AreaLayoutService(this.app, this.settings);
        this.areaCreationService = new AreaCreationService_1.AreaCreationService(this.app, this.settings);
        this.buttonService = new ButtonService_1.ButtonService(this.app, this.settings, this.notificationService, this.fileAnalysisService, this.areaCreationService, this.dataviewAdapter);
        this.viewManager = new ViewManager_1.ViewManager(this.app, this.buttonService, this.settings);
        // Register settings tab
        this.addSettingTab(new SettingsService_1.PrintTitleSettingTab(this.app, this));
        // Register event handlers
        this.registerEventHandlers();
        // Apply custom styles
        this.applyCustomStyles();
        // Expose global API for dataviewjs integration
        this.exposeGlobalAPI();
        // Add buttons to existing views after initialization
        setTimeout(() => {
            this.log('Adding buttons to existing notes');
            this.viewManager.addButtonToAllViews();
        }, 1000);
        this.log('Plugin loaded successfully');
    }
    onunload() {
        var _a;
        this.log('Unloading Print Title Plugin...');
        // Clean up all buttons and services
        (_a = this.viewManager) === null || _a === void 0 ? void 0 : _a.cleanup();
        // Remove custom styles
        if (this.customStyleEl) {
            this.customStyleEl.remove();
            this.customStyleEl = null;
        }
        this.log('Plugin unloaded');
    }
    /**
     * Register all event handlers
     */
    registerEventHandlers() {
        // File open event
        this.registerEvent(this.app.workspace.on('file-open', (file) => {
            this.viewManager.onFileOpen(file);
        }));
        // Active leaf change event
        this.registerEvent(this.app.workspace.on('active-leaf-change', (leaf) => {
            this.viewManager.onActiveLeafChange(leaf);
        }));
        // Layout change event (when switching between edit/preview mode)
        this.registerEvent(this.app.workspace.on('layout-change', () => {
            this.viewManager.onLayoutChange();
        }));
        // Workspace resize event
        this.registerEvent(this.app.workspace.on('resize', () => {
            // Refresh buttons after resize with a small delay
            setTimeout(() => {
                this.viewManager.refreshAllButtons();
            }, 200);
        }));
        this.log('Event handlers registered');
    }
    /**
     * Load plugin settings
     */
    async loadSettings() {
        this.settings = Object.assign({}, types_1.DEFAULT_SETTINGS, await this.loadData());
    }
    /**
     * Save plugin settings
     */
    async saveSettings() {
        var _a, _b, _c, _d, _e, _f;
        await this.saveData(this.settings);
        // Update services with new settings
        (_a = this.notificationService) === null || _a === void 0 ? void 0 : _a.updateSettings(this.settings);
        (_b = this.fileAnalysisService) === null || _b === void 0 ? void 0 : _b.updateSettings(this.settings);
        (_c = this.areaLayoutService) === null || _c === void 0 ? void 0 : _c.updateSettings(this.settings);
        (_d = this.areaCreationService) === null || _d === void 0 ? void 0 : _d.updateSettings(this.settings);
        (_e = this.buttonService) === null || _e === void 0 ? void 0 : _e.updateSettings(this.settings);
        (_f = this.viewManager) === null || _f === void 0 ? void 0 : _f.updateSettings(this.settings);
        this.log('Settings saved and services updated');
    }
    /**
     * Get default settings
     */
    getDefaultSettings() {
        return { ...types_1.DEFAULT_SETTINGS };
    }
    /**
     * Refresh all buttons (used by settings)
     */
    refreshAllButtons() {
        var _a;
        (_a = this.viewManager) === null || _a === void 0 ? void 0 : _a.refreshAllButtons();
    }
    /**
     * Apply custom CSS styles
     */
    applyCustomStyles() {
        // Remove existing custom styles
        if (this.customStyleEl) {
            this.customStyleEl.remove();
            this.customStyleEl = null;
        }
        // Apply new custom styles if any
        if (this.settings.customCSS.trim()) {
            this.customStyleEl = document.createElement('style');
            this.customStyleEl.textContent = `
				/* Print Title Plugin Custom Styles */
				${this.settings.customCSS}
			`;
            document.head.appendChild(this.customStyleEl);
            this.log('Custom styles applied');
        }
        // Apply base styles
        this.applyBaseStyles();
    }
    /**
     * Apply base plugin styles
     */
    applyBaseStyles() {
        const existingStyle = document.querySelector('#print-title-base-styles');
        if (!existingStyle) {
            const styleEl = document.createElement('style');
            styleEl.id = 'print-title-base-styles';
            styleEl.textContent = `
				/* Print Title Plugin Base Styles */
				.print-title-container {
					z-index: 10;
				}
				
				.print-title-button {
					font-family: var(--font-interface);
					white-space: nowrap;
					outline: none;
					user-select: none;
					-webkit-user-select: none;
					-moz-user-select: none;
					-ms-user-select: none;
				}
				
				.print-title-button:focus {
					outline: 2px solid var(--interactive-accent);
					outline-offset: 2px;
				}
				
				.print-title-button:active {
					transform: scale(0.95) !important;
				}
				
				/* Responsive adjustments */
				@media (max-width: 768px) {
					.print-title-container {
						margin: 12px 0;
						padding: 6px 16px;
					}
					
					.print-title-button {
						padding: 6px 12px;
						font-size: 12px;
					}
				}
				
				/* High contrast mode support */
				@media (prefers-contrast: high) {
					.print-title-button {
						border-width: 2px;
					}
				}
				
				/* Reduced motion support */
				@media (prefers-reduced-motion: reduce) {
					.print-title-button {
						transition: none;
					}
					
					.print-title-button:hover {
						transform: none;
					}
				}
			`;
            document.head.appendChild(styleEl);
        }
    }
    /**
     * Expose global API for dataviewjs integration
     */
    exposeGlobalAPI() {
        window.PrintTitleUI = {
            renderAreaLayout: async (dv, context) => {
                this.log('Global API: renderAreaLayout called');
                // Get current file context
                const activeFile = this.app.workspace.getActiveFile();
                if (!activeFile) {
                    console.error('[PrintTitle] No active file for area layout');
                    return;
                }
                // Check if this is an ems__Area
                const cache = this.app.metadataCache.getFileCache(activeFile);
                const frontmatter = cache === null || cache === void 0 ? void 0 : cache.frontmatter;
                if (!frontmatter || !frontmatter['exo__Instance_class']) {
                    dv.paragraph('This file is not an Exo asset.');
                    return;
                }
                const instanceClasses = Array.isArray(frontmatter['exo__Instance_class'])
                    ? frontmatter['exo__Instance_class']
                    : [frontmatter['exo__Instance_class']];
                const isArea = instanceClasses.some((cls) => { var _a; return typeof cls === 'string' ? cls.includes('ems__Area') : (_a = cls.path) === null || _a === void 0 ? void 0 : _a.includes('ems__Area'); });
                if (!isArea) {
                    dv.paragraph('This asset is not an ems__Area.');
                    return;
                }
                // Create file context
                const fileContext = {
                    fileName: activeFile.name,
                    filePath: activeFile.path,
                    file: activeFile,
                    frontmatter,
                    currentPage: {
                        file: {
                            path: activeFile.path,
                            name: activeFile.name,
                            link: null,
                            mtime: new Date(activeFile.stat.mtime)
                        },
                        'exo__Instance_class': frontmatter['exo__Instance_class'] || [],
                        ...frontmatter
                    }
                };
                // Get container element
                const container = dv.container;
                try {
                    await this.areaLayoutService.renderAreaLayout(container, fileContext);
                }
                catch (error) {
                    console.error('[PrintTitle] Error rendering area layout:', error);
                    dv.paragraph(`Error rendering area layout: ${error instanceof Error ? error.message : String(error)}`);
                }
            },
            createChildArea: async (parentContext) => {
                this.log('Global API: createChildArea called');
                await this.areaCreationService.createChildArea(parentContext);
            }
        };
        this.log('Global API exposed as window.PrintTitleUI');
    }
    /**
     * Debug logging
     */
    log(message, ...args) {
        var _a;
        if ((_a = this.settings) === null || _a === void 0 ? void 0 : _a.enableDebugMode) {
            console.log(`[PrintTitle] ${message}`, ...args);
        }
    }
}
exports.default = PrintTitlePlugin;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibWFpbi5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbInNyYy9tYWluLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBQUEsdUNBQTJFO0FBQzNFLG1DQUErRDtBQUMvRCw0REFBeUQ7QUFDekQsd0RBQXFEO0FBQ3JELGdFQUFrRTtBQUNsRSx3RUFBcUU7QUFDckUsd0VBQXFFO0FBQ3JFLGdFQUE2RDtBQUM3RCxvRUFBaUU7QUFDakUsd0VBQXFFO0FBRXJFLE1BQXFCLGdCQUFpQixTQUFRLGlCQUFNO0lBQXBEOztRQVNTLGtCQUFhLEdBQTRCLElBQUksQ0FBQztJQWlUdkQsQ0FBQztJQS9TQSxLQUFLLENBQUMsTUFBTTtRQUNYLElBQUksQ0FBQyxHQUFHLENBQUMsc0NBQXNDLENBQUMsQ0FBQztRQUVqRCxnQkFBZ0I7UUFDaEIsTUFBTSxJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7UUFFMUIsc0JBQXNCO1FBQ3RCLElBQUksQ0FBQyxtQkFBbUIsR0FBRyxJQUFJLHlDQUFtQixDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUNsRSxJQUFJLENBQUMsbUJBQW1CLEdBQUcsSUFBSSx5Q0FBbUIsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUM1RSxJQUFJLENBQUMsZUFBZSxHQUFHLElBQUksaUNBQWUsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7UUFDckQsSUFBSSxDQUFDLGlCQUFpQixHQUFHLElBQUkscUNBQWlCLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRSxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7UUFDeEUsSUFBSSxDQUFDLG1CQUFtQixHQUFHLElBQUkseUNBQW1CLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRSxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7UUFDNUUsSUFBSSxDQUFDLGFBQWEsR0FBRyxJQUFJLDZCQUFhLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRSxJQUFJLENBQUMsUUFBUSxFQUFFLElBQUksQ0FBQyxtQkFBbUIsRUFBRSxJQUFJLENBQUMsbUJBQW1CLEVBQUUsSUFBSSxDQUFDLG1CQUFtQixFQUFFLElBQUksQ0FBQyxlQUFlLENBQUMsQ0FBQztRQUNwSyxJQUFJLENBQUMsV0FBVyxHQUFHLElBQUkseUJBQVcsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFLElBQUksQ0FBQyxhQUFhLEVBQUUsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBRWhGLHdCQUF3QjtRQUN4QixJQUFJLENBQUMsYUFBYSxDQUFDLElBQUksc0NBQW9CLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRSxJQUFJLENBQUMsQ0FBQyxDQUFDO1FBRTdELDBCQUEwQjtRQUMxQixJQUFJLENBQUMscUJBQXFCLEVBQUUsQ0FBQztRQUU3QixzQkFBc0I7UUFDdEIsSUFBSSxDQUFDLGlCQUFpQixFQUFFLENBQUM7UUFFekIsK0NBQStDO1FBQy9DLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQztRQUV2QixxREFBcUQ7UUFDckQsVUFBVSxDQUFDLEdBQUcsRUFBRTtZQUNmLElBQUksQ0FBQyxHQUFHLENBQUMsa0NBQWtDLENBQUMsQ0FBQztZQUM3QyxJQUFJLENBQUMsV0FBVyxDQUFDLG1CQUFtQixFQUFFLENBQUM7UUFDeEMsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDO1FBRVQsSUFBSSxDQUFDLEdBQUcsQ0FBQyw0QkFBNEIsQ0FBQyxDQUFDO0lBQ3hDLENBQUM7SUFFRCxRQUFROztRQUNQLElBQUksQ0FBQyxHQUFHLENBQUMsaUNBQWlDLENBQUMsQ0FBQztRQUU1QyxvQ0FBb0M7UUFDcEMsTUFBQSxJQUFJLENBQUMsV0FBVywwQ0FBRSxPQUFPLEVBQUUsQ0FBQztRQUU1Qix1QkFBdUI7UUFDdkIsSUFBSSxJQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7WUFDeEIsSUFBSSxDQUFDLGFBQWEsQ0FBQyxNQUFNLEVBQUUsQ0FBQztZQUM1QixJQUFJLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQztRQUMzQixDQUFDO1FBRUQsSUFBSSxDQUFDLEdBQUcsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDO0lBQzdCLENBQUM7SUFFRDs7T0FFRztJQUNLLHFCQUFxQjtRQUM1QixrQkFBa0I7UUFDbEIsSUFBSSxDQUFDLGFBQWEsQ0FDakIsSUFBSSxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsRUFBRSxDQUFDLFdBQVcsRUFBRSxDQUFDLElBQWtCLEVBQUUsRUFBRTtZQUN6RCxJQUFJLENBQUMsV0FBVyxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUNuQyxDQUFDLENBQUMsQ0FDRixDQUFDO1FBRUYsMkJBQTJCO1FBQzNCLElBQUksQ0FBQyxhQUFhLENBQ2pCLElBQUksQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLEVBQUUsQ0FBQyxvQkFBb0IsRUFBRSxDQUFDLElBQTBCLEVBQUUsRUFBRTtZQUMxRSxJQUFJLENBQUMsV0FBVyxDQUFDLGtCQUFrQixDQUFDLElBQUksQ0FBQyxDQUFDO1FBQzNDLENBQUMsQ0FBQyxDQUNGLENBQUM7UUFFRixpRUFBaUU7UUFDakUsSUFBSSxDQUFDLGFBQWEsQ0FDakIsSUFBSSxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsRUFBRSxDQUFDLGVBQWUsRUFBRSxHQUFHLEVBQUU7WUFDM0MsSUFBSSxDQUFDLFdBQVcsQ0FBQyxjQUFjLEVBQUUsQ0FBQztRQUNuQyxDQUFDLENBQUMsQ0FDRixDQUFDO1FBRUYseUJBQXlCO1FBQ3pCLElBQUksQ0FBQyxhQUFhLENBQ2pCLElBQUksQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLEVBQUUsQ0FBQyxRQUFRLEVBQUUsR0FBRyxFQUFFO1lBQ3BDLGtEQUFrRDtZQUNsRCxVQUFVLENBQUMsR0FBRyxFQUFFO2dCQUNmLElBQUksQ0FBQyxXQUFXLENBQUMsaUJBQWlCLEVBQUUsQ0FBQztZQUN0QyxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUM7UUFDVCxDQUFDLENBQUMsQ0FDRixDQUFDO1FBRUYsSUFBSSxDQUFDLEdBQUcsQ0FBQywyQkFBMkIsQ0FBQyxDQUFDO0lBQ3ZDLENBQUM7SUFFRDs7T0FFRztJQUNILEtBQUssQ0FBQyxZQUFZO1FBQ2pCLElBQUksQ0FBQyxRQUFRLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFLEVBQUUsd0JBQWdCLEVBQUUsTUFBTSxJQUFJLENBQUMsUUFBUSxFQUFFLENBQUMsQ0FBQztJQUM1RSxDQUFDO0lBRUQ7O09BRUc7SUFDSCxLQUFLLENBQUMsWUFBWTs7UUFDakIsTUFBTSxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUVuQyxvQ0FBb0M7UUFDcEMsTUFBQSxJQUFJLENBQUMsbUJBQW1CLDBDQUFFLGNBQWMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7UUFDeEQsTUFBQSxJQUFJLENBQUMsbUJBQW1CLDBDQUFFLGNBQWMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7UUFDeEQsTUFBQSxJQUFJLENBQUMsaUJBQWlCLDBDQUFFLGNBQWMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7UUFDdEQsTUFBQSxJQUFJLENBQUMsbUJBQW1CLDBDQUFFLGNBQWMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7UUFDeEQsTUFBQSxJQUFJLENBQUMsYUFBYSwwQ0FBRSxjQUFjLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBQ2xELE1BQUEsSUFBSSxDQUFDLFdBQVcsMENBQUUsY0FBYyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUVoRCxJQUFJLENBQUMsR0FBRyxDQUFDLHFDQUFxQyxDQUFDLENBQUM7SUFDakQsQ0FBQztJQUVEOztPQUVHO0lBQ0gsa0JBQWtCO1FBQ2pCLE9BQU8sRUFBRSxHQUFHLHdCQUFnQixFQUFFLENBQUM7SUFDaEMsQ0FBQztJQUVEOztPQUVHO0lBQ0gsaUJBQWlCOztRQUNoQixNQUFBLElBQUksQ0FBQyxXQUFXLDBDQUFFLGlCQUFpQixFQUFFLENBQUM7SUFDdkMsQ0FBQztJQUVEOztPQUVHO0lBQ0gsaUJBQWlCO1FBQ2hCLGdDQUFnQztRQUNoQyxJQUFJLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztZQUN4QixJQUFJLENBQUMsYUFBYSxDQUFDLE1BQU0sRUFBRSxDQUFDO1lBQzVCLElBQUksQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDO1FBQzNCLENBQUM7UUFFRCxpQ0FBaUM7UUFDakMsSUFBSSxJQUFJLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxJQUFJLEVBQUUsRUFBRSxDQUFDO1lBQ3BDLElBQUksQ0FBQyxhQUFhLEdBQUcsUUFBUSxDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUMsQ0FBQztZQUNyRCxJQUFJLENBQUMsYUFBYSxDQUFDLFdBQVcsR0FBRzs7TUFFOUIsSUFBSSxDQUFDLFFBQVEsQ0FBQyxTQUFTO0lBQ3pCLENBQUM7WUFDRixRQUFRLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLENBQUM7WUFDOUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDO1FBQ25DLENBQUM7UUFFRCxvQkFBb0I7UUFDcEIsSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDO0lBQ3hCLENBQUM7SUFFRDs7T0FFRztJQUNLLGVBQWU7UUFDdEIsTUFBTSxhQUFhLEdBQUcsUUFBUSxDQUFDLGFBQWEsQ0FBQywwQkFBMEIsQ0FBQyxDQUFDO1FBQ3pFLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztZQUNwQixNQUFNLE9BQU8sR0FBRyxRQUFRLENBQUMsYUFBYSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1lBQ2hELE9BQU8sQ0FBQyxFQUFFLEdBQUcseUJBQXlCLENBQUM7WUFDdkMsT0FBTyxDQUFDLFdBQVcsR0FBRzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztJQXVEckIsQ0FBQztZQUNGLFFBQVEsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3BDLENBQUM7SUFDRixDQUFDO0lBRUQ7O09BRUc7SUFDSyxlQUFlO1FBQ3JCLE1BQWMsQ0FBQyxZQUFZLEdBQUc7WUFDOUIsZ0JBQWdCLEVBQUUsS0FBSyxFQUFFLEVBQU8sRUFBRSxPQUFZLEVBQUUsRUFBRTtnQkFDakQsSUFBSSxDQUFDLEdBQUcsQ0FBQyxxQ0FBcUMsQ0FBQyxDQUFDO2dCQUVoRCwyQkFBMkI7Z0JBQzNCLE1BQU0sVUFBVSxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLGFBQWEsRUFBRSxDQUFDO2dCQUN0RCxJQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7b0JBQ2pCLE9BQU8sQ0FBQyxLQUFLLENBQUMsNkNBQTZDLENBQUMsQ0FBQztvQkFDN0QsT0FBTztnQkFDUixDQUFDO2dCQUVELGdDQUFnQztnQkFDaEMsTUFBTSxLQUFLLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxhQUFhLENBQUMsWUFBWSxDQUFDLFVBQVUsQ0FBQyxDQUFDO2dCQUM5RCxNQUFNLFdBQVcsR0FBRyxLQUFLLGFBQUwsS0FBSyx1QkFBTCxLQUFLLENBQUUsV0FBVyxDQUFDO2dCQUV2QyxJQUFJLENBQUMsV0FBVyxJQUFJLENBQUMsV0FBVyxDQUFDLHFCQUFxQixDQUFDLEVBQUUsQ0FBQztvQkFDekQsRUFBRSxDQUFDLFNBQVMsQ0FBQyxnQ0FBZ0MsQ0FBQyxDQUFDO29CQUMvQyxPQUFPO2dCQUNSLENBQUM7Z0JBRUQsTUFBTSxlQUFlLEdBQUcsS0FBSyxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMscUJBQXFCLENBQUMsQ0FBQztvQkFDeEUsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxxQkFBcUIsQ0FBQztvQkFDcEMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLHFCQUFxQixDQUFDLENBQUMsQ0FBQztnQkFFeEMsTUFBTSxNQUFNLEdBQUcsZUFBZSxDQUFDLElBQUksQ0FBQyxDQUFDLEdBQVEsRUFBRSxFQUFFLFdBQ2hELE9BQUEsT0FBTyxHQUFHLEtBQUssUUFBUSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFBLEdBQUcsQ0FBQyxJQUFJLDBDQUFFLFFBQVEsQ0FBQyxXQUFXLENBQUMsQ0FBQSxFQUFBLENBQ3JGLENBQUM7Z0JBRUYsSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDO29CQUNiLEVBQUUsQ0FBQyxTQUFTLENBQUMsaUNBQWlDLENBQUMsQ0FBQztvQkFDaEQsT0FBTztnQkFDUixDQUFDO2dCQUVELHNCQUFzQjtnQkFDdEIsTUFBTSxXQUFXLEdBQUc7b0JBQ25CLFFBQVEsRUFBRSxVQUFVLENBQUMsSUFBSTtvQkFDekIsUUFBUSxFQUFFLFVBQVUsQ0FBQyxJQUFJO29CQUN6QixJQUFJLEVBQUUsVUFBVTtvQkFDaEIsV0FBVztvQkFDWCxXQUFXLEVBQUU7d0JBQ1osSUFBSSxFQUFFOzRCQUNMLElBQUksRUFBRSxVQUFVLENBQUMsSUFBSTs0QkFDckIsSUFBSSxFQUFFLFVBQVUsQ0FBQyxJQUFJOzRCQUNyQixJQUFJLEVBQUUsSUFBSTs0QkFDVixLQUFLLEVBQUUsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUM7eUJBQ3RDO3dCQUNELHFCQUFxQixFQUFFLFdBQVcsQ0FBQyxxQkFBcUIsQ0FBQyxJQUFJLEVBQUU7d0JBQy9ELEdBQUcsV0FBVztxQkFDZDtpQkFDRCxDQUFDO2dCQUVGLHdCQUF3QjtnQkFDeEIsTUFBTSxTQUFTLEdBQUcsRUFBRSxDQUFDLFNBQVMsQ0FBQztnQkFFL0IsSUFBSSxDQUFDO29CQUNKLE1BQU0sSUFBSSxDQUFDLGlCQUFpQixDQUFDLGdCQUFnQixDQUFDLFNBQVMsRUFBRSxXQUFXLENBQUMsQ0FBQztnQkFDdkUsQ0FBQztnQkFBQyxPQUFPLEtBQUssRUFBRSxDQUFDO29CQUNoQixPQUFPLENBQUMsS0FBSyxDQUFDLDJDQUEyQyxFQUFFLEtBQUssQ0FBQyxDQUFDO29CQUNsRSxFQUFFLENBQUMsU0FBUyxDQUFDLGdDQUFnQyxLQUFLLFlBQVksS0FBSyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxDQUFDO2dCQUN4RyxDQUFDO1lBQ0YsQ0FBQztZQUVELGVBQWUsRUFBRSxLQUFLLEVBQUUsYUFBa0IsRUFBRSxFQUFFO2dCQUM3QyxJQUFJLENBQUMsR0FBRyxDQUFDLG9DQUFvQyxDQUFDLENBQUM7Z0JBQy9DLE1BQU0sSUFBSSxDQUFDLG1CQUFtQixDQUFDLGVBQWUsQ0FBQyxhQUFhLENBQUMsQ0FBQztZQUMvRCxDQUFDO1NBQ0QsQ0FBQztRQUVGLElBQUksQ0FBQyxHQUFHLENBQUMsMkNBQTJDLENBQUMsQ0FBQztJQUN2RCxDQUFDO0lBRUQ7O09BRUc7SUFDSyxHQUFHLENBQUMsT0FBZSxFQUFFLEdBQUcsSUFBVzs7UUFDMUMsSUFBSSxNQUFBLElBQUksQ0FBQyxRQUFRLDBDQUFFLGVBQWUsRUFBRSxDQUFDO1lBQ3BDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZ0JBQWdCLE9BQU8sRUFBRSxFQUFFLEdBQUcsSUFBSSxDQUFDLENBQUM7UUFDakQsQ0FBQztJQUNGLENBQUM7Q0FDRDtBQTFURCxtQ0EwVEMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBBcHAsIFBsdWdpbiwgVEZpbGUsIFdvcmtzcGFjZUxlYWYsIE1hcmtkb3duVmlldyB9IGZyb20gJ29ic2lkaWFuJztcbmltcG9ydCB7IFByaW50VGl0bGVTZXR0aW5ncywgREVGQVVMVF9TRVRUSU5HUyB9IGZyb20gJy4vdHlwZXMnO1xuaW1wb3J0IHsgQnV0dG9uU2VydmljZSB9IGZyb20gJy4vc2VydmljZXMvQnV0dG9uU2VydmljZSc7XG5pbXBvcnQgeyBWaWV3TWFuYWdlciB9IGZyb20gJy4vc2VydmljZXMvVmlld01hbmFnZXInO1xuaW1wb3J0IHsgUHJpbnRUaXRsZVNldHRpbmdUYWIgfSBmcm9tICcuL3NlcnZpY2VzL1NldHRpbmdzU2VydmljZSc7XG5pbXBvcnQgeyBOb3RpZmljYXRpb25TZXJ2aWNlIH0gZnJvbSAnLi9zZXJ2aWNlcy9Ob3RpZmljYXRpb25TZXJ2aWNlJztcbmltcG9ydCB7IEZpbGVBbmFseXNpc1NlcnZpY2UgfSBmcm9tICcuL3NlcnZpY2VzL0ZpbGVBbmFseXNpc1NlcnZpY2UnO1xuaW1wb3J0IHsgRGF0YXZpZXdBZGFwdGVyIH0gZnJvbSAnLi9zZXJ2aWNlcy9EYXRhdmlld0FkYXB0ZXInO1xuaW1wb3J0IHsgQXJlYUxheW91dFNlcnZpY2UgfSBmcm9tICcuL3NlcnZpY2VzL0FyZWFMYXlvdXRTZXJ2aWNlJztcbmltcG9ydCB7IEFyZWFDcmVhdGlvblNlcnZpY2UgfSBmcm9tICcuL3NlcnZpY2VzL0FyZWFDcmVhdGlvblNlcnZpY2UnO1xuXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBQcmludFRpdGxlUGx1Z2luIGV4dGVuZHMgUGx1Z2luIHtcblx0c2V0dGluZ3MhOiBQcmludFRpdGxlU2V0dGluZ3M7XG5cdHByaXZhdGUgYnV0dG9uU2VydmljZSE6IEJ1dHRvblNlcnZpY2U7XG5cdHByaXZhdGUgdmlld01hbmFnZXIhOiBWaWV3TWFuYWdlcjtcblx0cHJpdmF0ZSBub3RpZmljYXRpb25TZXJ2aWNlITogTm90aWZpY2F0aW9uU2VydmljZTtcblx0cHJpdmF0ZSBmaWxlQW5hbHlzaXNTZXJ2aWNlITogRmlsZUFuYWx5c2lzU2VydmljZTtcblx0cHJpdmF0ZSBkYXRhdmlld0FkYXB0ZXIhOiBEYXRhdmlld0FkYXB0ZXI7XG5cdHByaXZhdGUgYXJlYUxheW91dFNlcnZpY2UhOiBBcmVhTGF5b3V0U2VydmljZTtcblx0cHJpdmF0ZSBhcmVhQ3JlYXRpb25TZXJ2aWNlITogQXJlYUNyZWF0aW9uU2VydmljZTtcblx0cHJpdmF0ZSBjdXN0b21TdHlsZUVsOiBIVE1MU3R5bGVFbGVtZW50IHwgbnVsbCA9IG51bGw7XG5cblx0YXN5bmMgb25sb2FkKCkge1xuXHRcdHRoaXMubG9nKCdMb2FkaW5nIFByaW50IFRpdGxlIFBsdWdpbiB2Mi4wLjAuLi4nKTtcblxuXHRcdC8vIExvYWQgc2V0dGluZ3Ncblx0XHRhd2FpdCB0aGlzLmxvYWRTZXR0aW5ncygpO1xuXG5cdFx0Ly8gSW5pdGlhbGl6ZSBzZXJ2aWNlc1xuXHRcdHRoaXMubm90aWZpY2F0aW9uU2VydmljZSA9IG5ldyBOb3RpZmljYXRpb25TZXJ2aWNlKHRoaXMuc2V0dGluZ3MpO1xuXHRcdHRoaXMuZmlsZUFuYWx5c2lzU2VydmljZSA9IG5ldyBGaWxlQW5hbHlzaXNTZXJ2aWNlKHRoaXMuYXBwLCB0aGlzLnNldHRpbmdzKTtcblx0XHR0aGlzLmRhdGF2aWV3QWRhcHRlciA9IG5ldyBEYXRhdmlld0FkYXB0ZXIodGhpcy5hcHApO1xuXHRcdHRoaXMuYXJlYUxheW91dFNlcnZpY2UgPSBuZXcgQXJlYUxheW91dFNlcnZpY2UodGhpcy5hcHAsIHRoaXMuc2V0dGluZ3MpO1xuXHRcdHRoaXMuYXJlYUNyZWF0aW9uU2VydmljZSA9IG5ldyBBcmVhQ3JlYXRpb25TZXJ2aWNlKHRoaXMuYXBwLCB0aGlzLnNldHRpbmdzKTtcblx0XHR0aGlzLmJ1dHRvblNlcnZpY2UgPSBuZXcgQnV0dG9uU2VydmljZSh0aGlzLmFwcCwgdGhpcy5zZXR0aW5ncywgdGhpcy5ub3RpZmljYXRpb25TZXJ2aWNlLCB0aGlzLmZpbGVBbmFseXNpc1NlcnZpY2UsIHRoaXMuYXJlYUNyZWF0aW9uU2VydmljZSwgdGhpcy5kYXRhdmlld0FkYXB0ZXIpO1xuXHRcdHRoaXMudmlld01hbmFnZXIgPSBuZXcgVmlld01hbmFnZXIodGhpcy5hcHAsIHRoaXMuYnV0dG9uU2VydmljZSwgdGhpcy5zZXR0aW5ncyk7XG5cblx0XHQvLyBSZWdpc3RlciBzZXR0aW5ncyB0YWJcblx0XHR0aGlzLmFkZFNldHRpbmdUYWIobmV3IFByaW50VGl0bGVTZXR0aW5nVGFiKHRoaXMuYXBwLCB0aGlzKSk7XG5cblx0XHQvLyBSZWdpc3RlciBldmVudCBoYW5kbGVyc1xuXHRcdHRoaXMucmVnaXN0ZXJFdmVudEhhbmRsZXJzKCk7XG5cblx0XHQvLyBBcHBseSBjdXN0b20gc3R5bGVzXG5cdFx0dGhpcy5hcHBseUN1c3RvbVN0eWxlcygpO1xuXG5cdFx0Ly8gRXhwb3NlIGdsb2JhbCBBUEkgZm9yIGRhdGF2aWV3anMgaW50ZWdyYXRpb25cblx0XHR0aGlzLmV4cG9zZUdsb2JhbEFQSSgpO1xuXG5cdFx0Ly8gQWRkIGJ1dHRvbnMgdG8gZXhpc3Rpbmcgdmlld3MgYWZ0ZXIgaW5pdGlhbGl6YXRpb25cblx0XHRzZXRUaW1lb3V0KCgpID0+IHtcblx0XHRcdHRoaXMubG9nKCdBZGRpbmcgYnV0dG9ucyB0byBleGlzdGluZyBub3RlcycpO1xuXHRcdFx0dGhpcy52aWV3TWFuYWdlci5hZGRCdXR0b25Ub0FsbFZpZXdzKCk7XG5cdFx0fSwgMTAwMCk7XG5cblx0XHR0aGlzLmxvZygnUGx1Z2luIGxvYWRlZCBzdWNjZXNzZnVsbHknKTtcblx0fVxuXG5cdG9udW5sb2FkKCkge1xuXHRcdHRoaXMubG9nKCdVbmxvYWRpbmcgUHJpbnQgVGl0bGUgUGx1Z2luLi4uJyk7XG5cdFx0XG5cdFx0Ly8gQ2xlYW4gdXAgYWxsIGJ1dHRvbnMgYW5kIHNlcnZpY2VzXG5cdFx0dGhpcy52aWV3TWFuYWdlcj8uY2xlYW51cCgpO1xuXHRcdFxuXHRcdC8vIFJlbW92ZSBjdXN0b20gc3R5bGVzXG5cdFx0aWYgKHRoaXMuY3VzdG9tU3R5bGVFbCkge1xuXHRcdFx0dGhpcy5jdXN0b21TdHlsZUVsLnJlbW92ZSgpO1xuXHRcdFx0dGhpcy5jdXN0b21TdHlsZUVsID0gbnVsbDtcblx0XHR9XG5cblx0XHR0aGlzLmxvZygnUGx1Z2luIHVubG9hZGVkJyk7XG5cdH1cblxuXHQvKipcblx0ICogUmVnaXN0ZXIgYWxsIGV2ZW50IGhhbmRsZXJzXG5cdCAqL1xuXHRwcml2YXRlIHJlZ2lzdGVyRXZlbnRIYW5kbGVycygpOiB2b2lkIHtcblx0XHQvLyBGaWxlIG9wZW4gZXZlbnRcblx0XHR0aGlzLnJlZ2lzdGVyRXZlbnQoXG5cdFx0XHR0aGlzLmFwcC53b3Jrc3BhY2Uub24oJ2ZpbGUtb3BlbicsIChmaWxlOiBURmlsZSB8IG51bGwpID0+IHtcblx0XHRcdFx0dGhpcy52aWV3TWFuYWdlci5vbkZpbGVPcGVuKGZpbGUpO1xuXHRcdFx0fSlcblx0XHQpO1xuXG5cdFx0Ly8gQWN0aXZlIGxlYWYgY2hhbmdlIGV2ZW50XG5cdFx0dGhpcy5yZWdpc3RlckV2ZW50KFxuXHRcdFx0dGhpcy5hcHAud29ya3NwYWNlLm9uKCdhY3RpdmUtbGVhZi1jaGFuZ2UnLCAobGVhZjogV29ya3NwYWNlTGVhZiB8IG51bGwpID0+IHtcblx0XHRcdFx0dGhpcy52aWV3TWFuYWdlci5vbkFjdGl2ZUxlYWZDaGFuZ2UobGVhZik7XG5cdFx0XHR9KVxuXHRcdCk7XG5cblx0XHQvLyBMYXlvdXQgY2hhbmdlIGV2ZW50ICh3aGVuIHN3aXRjaGluZyBiZXR3ZWVuIGVkaXQvcHJldmlldyBtb2RlKVxuXHRcdHRoaXMucmVnaXN0ZXJFdmVudChcblx0XHRcdHRoaXMuYXBwLndvcmtzcGFjZS5vbignbGF5b3V0LWNoYW5nZScsICgpID0+IHtcblx0XHRcdFx0dGhpcy52aWV3TWFuYWdlci5vbkxheW91dENoYW5nZSgpO1xuXHRcdFx0fSlcblx0XHQpO1xuXG5cdFx0Ly8gV29ya3NwYWNlIHJlc2l6ZSBldmVudFxuXHRcdHRoaXMucmVnaXN0ZXJFdmVudChcblx0XHRcdHRoaXMuYXBwLndvcmtzcGFjZS5vbigncmVzaXplJywgKCkgPT4ge1xuXHRcdFx0XHQvLyBSZWZyZXNoIGJ1dHRvbnMgYWZ0ZXIgcmVzaXplIHdpdGggYSBzbWFsbCBkZWxheVxuXHRcdFx0XHRzZXRUaW1lb3V0KCgpID0+IHtcblx0XHRcdFx0XHR0aGlzLnZpZXdNYW5hZ2VyLnJlZnJlc2hBbGxCdXR0b25zKCk7XG5cdFx0XHRcdH0sIDIwMCk7XG5cdFx0XHR9KVxuXHRcdCk7XG5cblx0XHR0aGlzLmxvZygnRXZlbnQgaGFuZGxlcnMgcmVnaXN0ZXJlZCcpO1xuXHR9XG5cblx0LyoqXG5cdCAqIExvYWQgcGx1Z2luIHNldHRpbmdzXG5cdCAqL1xuXHRhc3luYyBsb2FkU2V0dGluZ3MoKSB7XG5cdFx0dGhpcy5zZXR0aW5ncyA9IE9iamVjdC5hc3NpZ24oe30sIERFRkFVTFRfU0VUVElOR1MsIGF3YWl0IHRoaXMubG9hZERhdGEoKSk7XG5cdH1cblxuXHQvKipcblx0ICogU2F2ZSBwbHVnaW4gc2V0dGluZ3Ncblx0ICovXG5cdGFzeW5jIHNhdmVTZXR0aW5ncygpIHtcblx0XHRhd2FpdCB0aGlzLnNhdmVEYXRhKHRoaXMuc2V0dGluZ3MpO1xuXHRcdFxuXHRcdC8vIFVwZGF0ZSBzZXJ2aWNlcyB3aXRoIG5ldyBzZXR0aW5nc1xuXHRcdHRoaXMubm90aWZpY2F0aW9uU2VydmljZT8udXBkYXRlU2V0dGluZ3ModGhpcy5zZXR0aW5ncyk7XG5cdFx0dGhpcy5maWxlQW5hbHlzaXNTZXJ2aWNlPy51cGRhdGVTZXR0aW5ncyh0aGlzLnNldHRpbmdzKTtcblx0XHR0aGlzLmFyZWFMYXlvdXRTZXJ2aWNlPy51cGRhdGVTZXR0aW5ncyh0aGlzLnNldHRpbmdzKTtcblx0XHR0aGlzLmFyZWFDcmVhdGlvblNlcnZpY2U/LnVwZGF0ZVNldHRpbmdzKHRoaXMuc2V0dGluZ3MpO1xuXHRcdHRoaXMuYnV0dG9uU2VydmljZT8udXBkYXRlU2V0dGluZ3ModGhpcy5zZXR0aW5ncyk7XG5cdFx0dGhpcy52aWV3TWFuYWdlcj8udXBkYXRlU2V0dGluZ3ModGhpcy5zZXR0aW5ncyk7XG5cdFx0XG5cdFx0dGhpcy5sb2coJ1NldHRpbmdzIHNhdmVkIGFuZCBzZXJ2aWNlcyB1cGRhdGVkJyk7XG5cdH1cblxuXHQvKipcblx0ICogR2V0IGRlZmF1bHQgc2V0dGluZ3Ncblx0ICovXG5cdGdldERlZmF1bHRTZXR0aW5ncygpOiBQcmludFRpdGxlU2V0dGluZ3Mge1xuXHRcdHJldHVybiB7IC4uLkRFRkFVTFRfU0VUVElOR1MgfTtcblx0fVxuXG5cdC8qKlxuXHQgKiBSZWZyZXNoIGFsbCBidXR0b25zICh1c2VkIGJ5IHNldHRpbmdzKVxuXHQgKi9cblx0cmVmcmVzaEFsbEJ1dHRvbnMoKTogdm9pZCB7XG5cdFx0dGhpcy52aWV3TWFuYWdlcj8ucmVmcmVzaEFsbEJ1dHRvbnMoKTtcblx0fVxuXG5cdC8qKlxuXHQgKiBBcHBseSBjdXN0b20gQ1NTIHN0eWxlc1xuXHQgKi9cblx0YXBwbHlDdXN0b21TdHlsZXMoKTogdm9pZCB7XG5cdFx0Ly8gUmVtb3ZlIGV4aXN0aW5nIGN1c3RvbSBzdHlsZXNcblx0XHRpZiAodGhpcy5jdXN0b21TdHlsZUVsKSB7XG5cdFx0XHR0aGlzLmN1c3RvbVN0eWxlRWwucmVtb3ZlKCk7XG5cdFx0XHR0aGlzLmN1c3RvbVN0eWxlRWwgPSBudWxsO1xuXHRcdH1cblxuXHRcdC8vIEFwcGx5IG5ldyBjdXN0b20gc3R5bGVzIGlmIGFueVxuXHRcdGlmICh0aGlzLnNldHRpbmdzLmN1c3RvbUNTUy50cmltKCkpIHtcblx0XHRcdHRoaXMuY3VzdG9tU3R5bGVFbCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3N0eWxlJyk7XG5cdFx0XHR0aGlzLmN1c3RvbVN0eWxlRWwudGV4dENvbnRlbnQgPSBgXG5cdFx0XHRcdC8qIFByaW50IFRpdGxlIFBsdWdpbiBDdXN0b20gU3R5bGVzICovXG5cdFx0XHRcdCR7dGhpcy5zZXR0aW5ncy5jdXN0b21DU1N9XG5cdFx0XHRgO1xuXHRcdFx0ZG9jdW1lbnQuaGVhZC5hcHBlbmRDaGlsZCh0aGlzLmN1c3RvbVN0eWxlRWwpO1xuXHRcdFx0dGhpcy5sb2coJ0N1c3RvbSBzdHlsZXMgYXBwbGllZCcpO1xuXHRcdH1cblxuXHRcdC8vIEFwcGx5IGJhc2Ugc3R5bGVzXG5cdFx0dGhpcy5hcHBseUJhc2VTdHlsZXMoKTtcblx0fVxuXG5cdC8qKlxuXHQgKiBBcHBseSBiYXNlIHBsdWdpbiBzdHlsZXNcblx0ICovXG5cdHByaXZhdGUgYXBwbHlCYXNlU3R5bGVzKCk6IHZvaWQge1xuXHRcdGNvbnN0IGV4aXN0aW5nU3R5bGUgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCcjcHJpbnQtdGl0bGUtYmFzZS1zdHlsZXMnKTtcblx0XHRpZiAoIWV4aXN0aW5nU3R5bGUpIHtcblx0XHRcdGNvbnN0IHN0eWxlRWwgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdzdHlsZScpO1xuXHRcdFx0c3R5bGVFbC5pZCA9ICdwcmludC10aXRsZS1iYXNlLXN0eWxlcyc7XG5cdFx0XHRzdHlsZUVsLnRleHRDb250ZW50ID0gYFxuXHRcdFx0XHQvKiBQcmludCBUaXRsZSBQbHVnaW4gQmFzZSBTdHlsZXMgKi9cblx0XHRcdFx0LnByaW50LXRpdGxlLWNvbnRhaW5lciB7XG5cdFx0XHRcdFx0ei1pbmRleDogMTA7XG5cdFx0XHRcdH1cblx0XHRcdFx0XG5cdFx0XHRcdC5wcmludC10aXRsZS1idXR0b24ge1xuXHRcdFx0XHRcdGZvbnQtZmFtaWx5OiB2YXIoLS1mb250LWludGVyZmFjZSk7XG5cdFx0XHRcdFx0d2hpdGUtc3BhY2U6IG5vd3JhcDtcblx0XHRcdFx0XHRvdXRsaW5lOiBub25lO1xuXHRcdFx0XHRcdHVzZXItc2VsZWN0OiBub25lO1xuXHRcdFx0XHRcdC13ZWJraXQtdXNlci1zZWxlY3Q6IG5vbmU7XG5cdFx0XHRcdFx0LW1vei11c2VyLXNlbGVjdDogbm9uZTtcblx0XHRcdFx0XHQtbXMtdXNlci1zZWxlY3Q6IG5vbmU7XG5cdFx0XHRcdH1cblx0XHRcdFx0XG5cdFx0XHRcdC5wcmludC10aXRsZS1idXR0b246Zm9jdXMge1xuXHRcdFx0XHRcdG91dGxpbmU6IDJweCBzb2xpZCB2YXIoLS1pbnRlcmFjdGl2ZS1hY2NlbnQpO1xuXHRcdFx0XHRcdG91dGxpbmUtb2Zmc2V0OiAycHg7XG5cdFx0XHRcdH1cblx0XHRcdFx0XG5cdFx0XHRcdC5wcmludC10aXRsZS1idXR0b246YWN0aXZlIHtcblx0XHRcdFx0XHR0cmFuc2Zvcm06IHNjYWxlKDAuOTUpICFpbXBvcnRhbnQ7XG5cdFx0XHRcdH1cblx0XHRcdFx0XG5cdFx0XHRcdC8qIFJlc3BvbnNpdmUgYWRqdXN0bWVudHMgKi9cblx0XHRcdFx0QG1lZGlhIChtYXgtd2lkdGg6IDc2OHB4KSB7XG5cdFx0XHRcdFx0LnByaW50LXRpdGxlLWNvbnRhaW5lciB7XG5cdFx0XHRcdFx0XHRtYXJnaW46IDEycHggMDtcblx0XHRcdFx0XHRcdHBhZGRpbmc6IDZweCAxNnB4O1xuXHRcdFx0XHRcdH1cblx0XHRcdFx0XHRcblx0XHRcdFx0XHQucHJpbnQtdGl0bGUtYnV0dG9uIHtcblx0XHRcdFx0XHRcdHBhZGRpbmc6IDZweCAxMnB4O1xuXHRcdFx0XHRcdFx0Zm9udC1zaXplOiAxMnB4O1xuXHRcdFx0XHRcdH1cblx0XHRcdFx0fVxuXHRcdFx0XHRcblx0XHRcdFx0LyogSGlnaCBjb250cmFzdCBtb2RlIHN1cHBvcnQgKi9cblx0XHRcdFx0QG1lZGlhIChwcmVmZXJzLWNvbnRyYXN0OiBoaWdoKSB7XG5cdFx0XHRcdFx0LnByaW50LXRpdGxlLWJ1dHRvbiB7XG5cdFx0XHRcdFx0XHRib3JkZXItd2lkdGg6IDJweDtcblx0XHRcdFx0XHR9XG5cdFx0XHRcdH1cblx0XHRcdFx0XG5cdFx0XHRcdC8qIFJlZHVjZWQgbW90aW9uIHN1cHBvcnQgKi9cblx0XHRcdFx0QG1lZGlhIChwcmVmZXJzLXJlZHVjZWQtbW90aW9uOiByZWR1Y2UpIHtcblx0XHRcdFx0XHQucHJpbnQtdGl0bGUtYnV0dG9uIHtcblx0XHRcdFx0XHRcdHRyYW5zaXRpb246IG5vbmU7XG5cdFx0XHRcdFx0fVxuXHRcdFx0XHRcdFxuXHRcdFx0XHRcdC5wcmludC10aXRsZS1idXR0b246aG92ZXIge1xuXHRcdFx0XHRcdFx0dHJhbnNmb3JtOiBub25lO1xuXHRcdFx0XHRcdH1cblx0XHRcdFx0fVxuXHRcdFx0YDtcblx0XHRcdGRvY3VtZW50LmhlYWQuYXBwZW5kQ2hpbGQoc3R5bGVFbCk7XG5cdFx0fVxuXHR9XG5cblx0LyoqXG5cdCAqIEV4cG9zZSBnbG9iYWwgQVBJIGZvciBkYXRhdmlld2pzIGludGVncmF0aW9uXG5cdCAqL1xuXHRwcml2YXRlIGV4cG9zZUdsb2JhbEFQSSgpOiB2b2lkIHtcblx0XHQod2luZG93IGFzIGFueSkuUHJpbnRUaXRsZVVJID0ge1xuXHRcdFx0cmVuZGVyQXJlYUxheW91dDogYXN5bmMgKGR2OiBhbnksIGNvbnRleHQ6IGFueSkgPT4ge1xuXHRcdFx0XHR0aGlzLmxvZygnR2xvYmFsIEFQSTogcmVuZGVyQXJlYUxheW91dCBjYWxsZWQnKTtcblx0XHRcdFx0XG5cdFx0XHRcdC8vIEdldCBjdXJyZW50IGZpbGUgY29udGV4dFxuXHRcdFx0XHRjb25zdCBhY3RpdmVGaWxlID0gdGhpcy5hcHAud29ya3NwYWNlLmdldEFjdGl2ZUZpbGUoKTtcblx0XHRcdFx0aWYgKCFhY3RpdmVGaWxlKSB7XG5cdFx0XHRcdFx0Y29uc29sZS5lcnJvcignW1ByaW50VGl0bGVdIE5vIGFjdGl2ZSBmaWxlIGZvciBhcmVhIGxheW91dCcpO1xuXHRcdFx0XHRcdHJldHVybjtcblx0XHRcdFx0fVxuXG5cdFx0XHRcdC8vIENoZWNrIGlmIHRoaXMgaXMgYW4gZW1zX19BcmVhXG5cdFx0XHRcdGNvbnN0IGNhY2hlID0gdGhpcy5hcHAubWV0YWRhdGFDYWNoZS5nZXRGaWxlQ2FjaGUoYWN0aXZlRmlsZSk7XG5cdFx0XHRcdGNvbnN0IGZyb250bWF0dGVyID0gY2FjaGU/LmZyb250bWF0dGVyO1xuXHRcdFx0XHRcblx0XHRcdFx0aWYgKCFmcm9udG1hdHRlciB8fCAhZnJvbnRtYXR0ZXJbJ2V4b19fSW5zdGFuY2VfY2xhc3MnXSkge1xuXHRcdFx0XHRcdGR2LnBhcmFncmFwaCgnVGhpcyBmaWxlIGlzIG5vdCBhbiBFeG8gYXNzZXQuJyk7XG5cdFx0XHRcdFx0cmV0dXJuO1xuXHRcdFx0XHR9XG5cblx0XHRcdFx0Y29uc3QgaW5zdGFuY2VDbGFzc2VzID0gQXJyYXkuaXNBcnJheShmcm9udG1hdHRlclsnZXhvX19JbnN0YW5jZV9jbGFzcyddKSBcblx0XHRcdFx0XHQ/IGZyb250bWF0dGVyWydleG9fX0luc3RhbmNlX2NsYXNzJ10gXG5cdFx0XHRcdFx0OiBbZnJvbnRtYXR0ZXJbJ2V4b19fSW5zdGFuY2VfY2xhc3MnXV07XG5cdFx0XHRcdFxuXHRcdFx0XHRjb25zdCBpc0FyZWEgPSBpbnN0YW5jZUNsYXNzZXMuc29tZSgoY2xzOiBhbnkpID0+IFxuXHRcdFx0XHRcdHR5cGVvZiBjbHMgPT09ICdzdHJpbmcnID8gY2xzLmluY2x1ZGVzKCdlbXNfX0FyZWEnKSA6IGNscy5wYXRoPy5pbmNsdWRlcygnZW1zX19BcmVhJylcblx0XHRcdFx0KTtcblxuXHRcdFx0XHRpZiAoIWlzQXJlYSkge1xuXHRcdFx0XHRcdGR2LnBhcmFncmFwaCgnVGhpcyBhc3NldCBpcyBub3QgYW4gZW1zX19BcmVhLicpO1xuXHRcdFx0XHRcdHJldHVybjtcblx0XHRcdFx0fVxuXG5cdFx0XHRcdC8vIENyZWF0ZSBmaWxlIGNvbnRleHRcblx0XHRcdFx0Y29uc3QgZmlsZUNvbnRleHQgPSB7XG5cdFx0XHRcdFx0ZmlsZU5hbWU6IGFjdGl2ZUZpbGUubmFtZSxcblx0XHRcdFx0XHRmaWxlUGF0aDogYWN0aXZlRmlsZS5wYXRoLFxuXHRcdFx0XHRcdGZpbGU6IGFjdGl2ZUZpbGUsXG5cdFx0XHRcdFx0ZnJvbnRtYXR0ZXIsXG5cdFx0XHRcdFx0Y3VycmVudFBhZ2U6IHtcblx0XHRcdFx0XHRcdGZpbGU6IHtcblx0XHRcdFx0XHRcdFx0cGF0aDogYWN0aXZlRmlsZS5wYXRoLFxuXHRcdFx0XHRcdFx0XHRuYW1lOiBhY3RpdmVGaWxlLm5hbWUsXG5cdFx0XHRcdFx0XHRcdGxpbms6IG51bGwsXG5cdFx0XHRcdFx0XHRcdG10aW1lOiBuZXcgRGF0ZShhY3RpdmVGaWxlLnN0YXQubXRpbWUpXG5cdFx0XHRcdFx0XHR9LFxuXHRcdFx0XHRcdFx0J2V4b19fSW5zdGFuY2VfY2xhc3MnOiBmcm9udG1hdHRlclsnZXhvX19JbnN0YW5jZV9jbGFzcyddIHx8IFtdLFxuXHRcdFx0XHRcdFx0Li4uZnJvbnRtYXR0ZXJcblx0XHRcdFx0XHR9XG5cdFx0XHRcdH07XG5cblx0XHRcdFx0Ly8gR2V0IGNvbnRhaW5lciBlbGVtZW50XG5cdFx0XHRcdGNvbnN0IGNvbnRhaW5lciA9IGR2LmNvbnRhaW5lcjtcblx0XHRcdFx0XG5cdFx0XHRcdHRyeSB7XG5cdFx0XHRcdFx0YXdhaXQgdGhpcy5hcmVhTGF5b3V0U2VydmljZS5yZW5kZXJBcmVhTGF5b3V0KGNvbnRhaW5lciwgZmlsZUNvbnRleHQpO1xuXHRcdFx0XHR9IGNhdGNoIChlcnJvcikge1xuXHRcdFx0XHRcdGNvbnNvbGUuZXJyb3IoJ1tQcmludFRpdGxlXSBFcnJvciByZW5kZXJpbmcgYXJlYSBsYXlvdXQ6JywgZXJyb3IpO1xuXHRcdFx0XHRcdGR2LnBhcmFncmFwaChgRXJyb3IgcmVuZGVyaW5nIGFyZWEgbGF5b3V0OiAke2Vycm9yIGluc3RhbmNlb2YgRXJyb3IgPyBlcnJvci5tZXNzYWdlIDogU3RyaW5nKGVycm9yKX1gKTtcblx0XHRcdFx0fVxuXHRcdFx0fSxcblxuXHRcdFx0Y3JlYXRlQ2hpbGRBcmVhOiBhc3luYyAocGFyZW50Q29udGV4dDogYW55KSA9PiB7XG5cdFx0XHRcdHRoaXMubG9nKCdHbG9iYWwgQVBJOiBjcmVhdGVDaGlsZEFyZWEgY2FsbGVkJyk7XG5cdFx0XHRcdGF3YWl0IHRoaXMuYXJlYUNyZWF0aW9uU2VydmljZS5jcmVhdGVDaGlsZEFyZWEocGFyZW50Q29udGV4dCk7XG5cdFx0XHR9XG5cdFx0fTtcblxuXHRcdHRoaXMubG9nKCdHbG9iYWwgQVBJIGV4cG9zZWQgYXMgd2luZG93LlByaW50VGl0bGVVSScpO1xuXHR9XG5cblx0LyoqXG5cdCAqIERlYnVnIGxvZ2dpbmdcblx0ICovXG5cdHByaXZhdGUgbG9nKG1lc3NhZ2U6IHN0cmluZywgLi4uYXJnczogYW55W10pOiB2b2lkIHtcblx0XHRpZiAodGhpcy5zZXR0aW5ncz8uZW5hYmxlRGVidWdNb2RlKSB7XG5cdFx0XHRjb25zb2xlLmxvZyhgW1ByaW50VGl0bGVdICR7bWVzc2FnZX1gLCAuLi5hcmdzKTtcblx0XHR9XG5cdH1cbn0iXX0=